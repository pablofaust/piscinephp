SELECT COUNT(duration) AS nb_short_films FROM film WHERE duration <= 42;
