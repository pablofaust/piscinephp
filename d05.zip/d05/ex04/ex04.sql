UPDATE ft_table SET creation_date = creation_date + interval '20' year WHERE id > 5;
